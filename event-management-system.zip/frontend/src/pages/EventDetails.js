"use client"

import { useState, useEffect, useContext } from "react"
import { useParams, useNavigate } from "react-router-dom"
import axios from "axios"
import { toast } from "react-toastify"
import { format } from "date-fns"
import AuthContext from "../context/AuthContext"

const EventDetails = () => {
  const { id } = useParams()
  const { isAuthenticated } = useContext(AuthContext)
  const navigate = useNavigate()

  const [event, setEvent] = useState(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)
  const [registering, setRegistering] = useState(false)

  useEffect(() => {
    const fetchEvent = async () => {
      try {
        const res = await axios.get(`/api/events/${id}`)
        setEvent(res.data)
        setLoading(false)
      } catch (err) {
        setError("Failed to fetch event details")
        setLoading(false)
      }
    }

    fetchEvent()
  }, [id])

  const handleRegister = async () => {
    if (!isAuthenticated) {
      toast.info("Please login to register for this event")
      navigate("/login")
      return
    }

    try {
      setRegistering(true)
      await axios.post("/api/registrations", { eventId: id })
      toast.success("Registration successful!")
      navigate("/my-registrations")
    } catch (err) {
      toast.error(err.response?.data?.message || "Registration failed")
    } finally {
      setRegistering(false)
    }
  }

  if (loading) {
    return (
      <div className="flex justify-center items-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-indigo-500"></div>
      </div>
    )
  }

  if (error || !event) {
    return (
      <div className="text-center py-10">
        <p className="text-red-500">{error || "Event not found"}</p>
        <button
          onClick={() => navigate("/")}
          className="mt-4 px-4 py-2 bg-indigo-600 text-white rounded-md hover:bg-indigo-700"
        >
          Back to Home
        </button>
      </div>
    )
  }

  return (
    <div className="bg-white shadow overflow-hidden sm:rounded-lg">
      <div className="px-4 py-5 sm:px-6">
        <h1 className="text-3xl font-bold text-gray-900">{event.ename}</h1>
        <p className="mt-1 max-w-2xl text-sm text-gray-500">Organized by {event.organizer}</p>
      </div>
      <div className="border-t border-gray-200">
        <dl>
          <div className="bg-gray-50 px-4 py-5 sm:grid sm:grid-cols-3 sm:gap-4 sm:px-6">
            <dt className="text-sm font-medium text-gray-500">Date</dt>
            <dd className="mt-1 text-sm text-gray-900 sm:mt-0 sm:col-span-2">
              {format(new Date(event.date), "EEEE, MMMM d, yyyy")}
            </dd>
          </div>
          <div className="bg-white px-4 py-5 sm:grid sm:grid-cols-3 sm:gap-4 sm:px-6">
            <dt className="text-sm font-medium text-gray-500">Venue</dt>
            <dd className="mt-1 text-sm text-gray-900 sm:mt-0 sm:col-span-2">
              {event.venue?.location || "Location TBA"}
              {event.venue?.capacity && <span className="ml-2 text-gray-500">(Capacity: {event.venue.capacity})</span>}
            </dd>
          </div>
          <div className="bg-gray-50 px-4 py-5 sm:grid sm:grid-cols-3 sm:gap-4 sm:px-6">
            <dt className="text-sm font-medium text-gray-500">Entry Fee</dt>
            <dd className="mt-1 text-sm text-gray-900 sm:mt-0 sm:col-span-2">${event.entryFee}</dd>
          </div>
          <div className="bg-white px-4 py-5 sm:grid sm:grid-cols-3 sm:gap-4 sm:px-6">
            <dt className="text-sm font-medium text-gray-500">Contact</dt>
            <dd className="mt-1 text-sm text-gray-900 sm:mt-0 sm:col-span-2">{event.phoneNo}</dd>
          </div>
          <div className="bg-gray-50 px-4 py-5 sm:px-6">
            <div className="flex justify-end">
              <button
                onClick={handleRegister}
                disabled={registering}
                className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
              >
                {registering ? "Processing..." : "Register for Event"}
              </button>
            </div>
          </div>
        </dl>
      </div>
    </div>
  )
}

export default EventDetails
