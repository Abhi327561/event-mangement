"use client"

import { useState, useEffect } from "react"
import { Link } from "react-router-dom"
import axios from "axios"
import { toast } from "react-toastify"
import { format } from "date-fns"

const MyRegistrations = () => {
  const [registrations, setRegistrations] = useState([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const fetchMyRegistrations = async () => {
      try {
        const res = await axios.get("/api/registrations")
        setRegistrations(res.data)
        setLoading(false)
      } catch (err) {
        toast.error("Failed to fetch your registrations")
        setLoading(false)
      }
    }

    fetchMyRegistrations()
  }, [])

  const handleCancelRegistration = async (id) => {
    if (window.confirm("Are you sure you want to cancel this registration?")) {
      try {
        await axios.delete(`/api/registrations/${id}`)
        setRegistrations(registrations.filter((reg) => reg._id !== id))
        toast.success("Registration cancelled successfully")
      } catch (err) {
        toast.error(err.response?.data?.message || "Failed to cancel registration")
      }
    }
  }

  if (loading) {
    return (
      <div className="flex justify-center items-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-indigo-500"></div>
      </div>
    )
  }

  return (
    <div>
      <h1 className="text-3xl font-bold mb-6">My Registrations</h1>

      {registrations.length === 0 ? (
        <div className="bg-white shadow-md rounded-lg p-6 text-center">
          <svg
            className="mx-auto h-12 w-12 text-gray-400"
            fill="none"
            stroke="currentColor"
            viewBox="0 0 24 24"
            xmlns="http://www.w3.org/2000/svg"
          >
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth="2"
              d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z"
            ></path>
          </svg>
          <h3 className="mt-2 text-sm font-medium text-gray-900">No registrations</h3>
          <p className="mt-1 text-sm text-gray-500">You haven't registered for any events yet.</p>
          <div className="mt-6">
            <Link
              to="/"
              className="inline-flex items-center px-4 py-2 border border-transparent shadow-sm text-sm font-medium rounded-md text-white bg-indigo-600 hover:bg-indigo-700"
            >
              Browse Events
            </Link>
          </div>
        </div>
      ) : (
        <div className="overflow-x-auto">
          <table className="min-w-full bg-white">
            <thead>
              <tr>
                <th className="py-3 px-6 text-left bg-gray-100 font-semibold text-gray-600 uppercase tracking-wider">
                  Event
                </th>
                <th className="py-3 px-6 text-left bg-gray-100 font-semibold text-gray-600 uppercase tracking-wider">
                  Registration Date
                </th>
                <th className="py-3 px-6 text-left bg-gray-100 font-semibold text-gray-600 uppercase tracking-wider">
                  Event Date
                </th>
                <th className="py-3 px-6 text-left bg-gray-100 font-semibold text-gray-600 uppercase tracking-wider">
                  Status
                </th>
                <th className="py-3 px-6 text-center bg-gray-100 font-semibold text-gray-600 uppercase tracking-wider">
                  Actions
                </th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-200">
              {registrations.map((registration) => (
                <tr key={registration._id}>
                  <td className="py-4 px-6 border-b border-gray-200">
                    <Link to={`/event/${registration.eventId._id}`} className="text-indigo-600 hover:text-indigo-900">
                      {registration.eventId.ename}
                    </Link>
                  </td>
                  <td className="py-4 px-6 border-b border-gray-200">
                    {format(new Date(registration.regDate), "MMM d, yyyy")}
                  </td>
                  <td className="py-4 px-6 border-b border-gray-200">
                    {format(new Date(registration.eventId.date), "MMM d, yyyy")}
                  </td>
                  <td className="py-4 px-6 border-b border-gray-200">
                    <span
                      className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${
                        registration.transaction?.status === "completed"
                          ? "bg-green-100 text-green-800"
                          : "bg-yellow-100 text-yellow-800"
                      }`}
                    >
                      {registration.transaction?.status === "completed" ? "Paid" : "Pending"}
                    </span>
                  </td>
                  <td className="py-4 px-6 border-b border-gray-200 text-center">
                    <button
                      onClick={() => handleCancelRegistration(registration._id)}
                      className="text-red-600 hover:text-red-900"
                    >
                      Cancel
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  )
}

export default MyRegistrations
