"use client"

import { useState, useEffect } from "react"
import { Link } from "react-router-dom"
import axios from "axios"
import { toast } from "react-toastify"
import { format } from "date-fns"

const MyEvents = () => {
  const [events, setEvents] = useState([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const fetchMyEvents = async () => {
      try {
        const res = await axios.get("/api/events/myevents")
        setEvents(res.data)
        setLoading(false)
      } catch (err) {
        toast.error("Failed to fetch your events")
        setLoading(false)
      }
    }

    fetchMyEvents()
  }, [])

  const handleDeleteEvent = async (id) => {
    if (window.confirm("Are you sure you want to delete this event?")) {
      try {
        await axios.delete(`/api/events/${id}`)
        setEvents(events.filter((event) => event._id !== id))
        toast.success("Event deleted successfully")
      } catch (err) {
        toast.error(err.response?.data?.message || "Failed to delete event")
      }
    }
  }

  if (loading) {
    return (
      <div className="flex justify-center items-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-indigo-500"></div>
      </div>
    )
  }

  return (
    <div>
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-3xl font-bold">My Events</h1>
        <Link to="/create-event" className="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded">
          Create New Event
        </Link>
      </div>

      {events.length === 0 ? (
        <div className="bg-white shadow-md rounded-lg p-6 text-center">
          <svg
            className="mx-auto h-12 w-12 text-gray-400"
            fill="none"
            stroke="currentColor"
            viewBox="0 0 24 24"
            xmlns="http://www.w3.org/2000/svg"
          >
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth="2"
              d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z"
            ></path>
          </svg>
          <h3 className="mt-2 text-sm font-medium text-gray-900">No events</h3>
          <p className="mt-1 text-sm text-gray-500">Get started by creating a new event.</p>
          <div className="mt-6">
            <Link
              to="/create-event"
              className="inline-flex items-center px-4 py-2 border border-transparent shadow-sm text-sm font-medium rounded-md text-white bg-indigo-600 hover:bg-indigo-700"
            >
              Create New Event
            </Link>
          </div>
        </div>
      ) : (
        <div className="overflow-x-auto">
          <table className="min-w-full bg-white">
            <thead>
              <tr>
                <th className="py-3 px-6 text-left bg-gray-100 font-semibold text-gray-600 uppercase tracking-wider">
                  Event Name
                </th>
                <th className="py-3 px-6 text-left bg-gray-100 font-semibold text-gray-600 uppercase tracking-wider">
                  Date
                </th>
                <th className="py-3 px-6 text-left bg-gray-100 font-semibold text-gray-600 uppercase tracking-wider">
                  Location
                </th>
                <th className="py-3 px-6 text-left bg-gray-100 font-semibold text-gray-600 uppercase tracking-wider">
                  Entry Fee
                </th>
                <th className="py-3 px-6 text-center bg-gray-100 font-semibold text-gray-600 uppercase tracking-wider">
                  Actions
                </th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-200">
              {events.map((event) => (
                <tr key={event._id}>
                  <td className="py-4 px-6 border-b border-gray-200">
                    <Link to={`/event/${event._id}`} className="text-indigo-600 hover:text-indigo-900">
                      {event.ename}
                    </Link>
                  </td>
                  <td className="py-4 px-6 border-b border-gray-200">{format(new Date(event.date), "MMM d, yyyy")}</td>
                  <td className="py-4 px-6 border-b border-gray-200">{event.venue?.location || "N/A"}</td>
                  <td className="py-4 px-6 border-b border-gray-200">${event.entryFee}</td>
                  <td className="py-4 px-6 border-b border-gray-200 text-center">
                    <Link to={`/edit-event/${event._id}`} className="text-indigo-600 hover:text-indigo-900 mr-4">
                      Edit
                    </Link>
                    <button onClick={() => handleDeleteEvent(event._id)} className="text-red-600 hover:text-red-900">
                      Delete
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  )
}

export default MyEvents
