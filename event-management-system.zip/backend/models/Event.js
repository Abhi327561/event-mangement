import mongoose from "mongoose"

const eventSchema = new mongoose.Schema(
  {
    ename: {
      type: String,
      required: true,
    },
    date: {
      type: Date,
      required: true,
    },
    entryFee: {
      type: Number,
      required: true,
    },
    phoneNo: {
      type: String,
      required: true,
    },
    organizer: {
      type: String,
      required: true,
    },
    user: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      required: true,
    },
    eventId: {
      type: String,
      required: true,
      unique: true,
    },
  },
  { timestamps: true },
)

const Event = mongoose.model("Event", eventSchema)

export default Event
