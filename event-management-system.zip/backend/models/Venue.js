import mongoose from "mongoose"

const venueSchema = new mongoose.Schema(
  {
    location: {
      type: String,
      required: true,
    },
    capacity: {
      type: Number,
      required: true,
    },
    fee: {
      type: Number,
      required: true,
    },
    event: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Event",
      required: true,
    },
  },
  { timestamps: true },
)

const Venue = mongoose.model("Venue", venueSchema)

export default Venue
