import mongoose from "mongoose"

const registrationSchema = new mongoose.Schema(
  {
    name: {
      type: String,
      required: true,
    },
    regDate: {
      type: Date,
      default: Date.now,
    },
    regId: {
      type: String,
      required: true,
      unique: true,
    },
    eventId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Event",
      required: true,
    },
    user: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      required: true,
    },
  },
  { timestamps: true },
)

const Registration = mongoose.model("Registration", registrationSchema)

export default Registration
