import Event from "../models/Event.js"
import Venue from "../models/Venue.js"
import Registration from "../models/Registration.js"
import { v4 as uuidv4 } from "uuid"

// Create a new event
export const createEvent = async (req, res) => {
  try {
    const { ename, date, entryFee, phoneNo, organizer, location, capacity, fee } = req.body

    // Create event
    const event = await Event.create({
      ename,
      date,
      entryFee,
      phoneNo,
      organizer,
      user: req.user._id,
      eventId: uuidv4(),
    })

    // Create venue
    const venue = await Venue.create({
      location,
      capacity,
      fee,
      event: event._id,
    })

    res.status(201).json({
      event,
      venue,
    })
  } catch (error) {
    console.error(error)
    res.status(500).json({ message: "Server error" })
  }
}

// Get all events
export const getEvents = async (req, res) => {
  try {
    const events = await Event.find({}).sort({ date: 1 })
    res.json(events)
  } catch (error) {
    console.error(error)
    res.status(500).json({ message: "Server error" })
  }
}

// Get event by ID
export const getEventById = async (req, res) => {
  try {
    const event = await Event.findById(req.params.id)
    const venue = await Venue.findOne({ event: req.params.id })

    if (event) {
      res.json({
        ...event._doc,
        venue,
      })
    } else {
      res.status(404).json({ message: "Event not found" })
    }
  } catch (error) {
    console.error(error)
    res.status(500).json({ message: "Server error" })
  }
}

// Update event
export const updateEvent = async (req, res) => {
  try {
    const { ename, date, entryFee, phoneNo, organizer, location, capacity, fee } = req.body

    const event = await Event.findById(req.params.id)

    if (!event) {
      return res.status(404).json({ message: "Event not found" })
    }

    // Check if user is the event creator
    if (event.user.toString() !== req.user._id.toString()) {
      return res.status(401).json({ message: "Not authorized" })
    }

    // Update event
    event.ename = ename || event.ename
    event.date = date || event.date
    event.entryFee = entryFee || event.entryFee
    event.phoneNo = phoneNo || event.phoneNo
    event.organizer = organizer || event.organizer

    await event.save()

    // Update venue
    const venue = await Venue.findOne({ event: req.params.id })

    if (venue) {
      venue.location = location || venue.location
      venue.capacity = capacity || venue.capacity
      venue.fee = fee || venue.fee

      await venue.save()
    }

    res.json({
      ...event._doc,
      venue,
    })
  } catch (error) {
    console.error(error)
    res.status(500).json({ message: "Server error" })
  }
}

// Delete event
export const deleteEvent = async (req, res) => {
  try {
    const event = await Event.findById(req.params.id)

    if (!event) {
      return res.status(404).json({ message: "Event not found" })
    }

    // Check if user is the event creator
    if (event.user.toString() !== req.user._id.toString()) {
      return res.status(401).json({ message: "Not authorized" })
    }

    // Check if there are registrations
    const registrations = await Registration.find({ eventId: req.params.id })

    if (registrations.length > 0) {
      return res.status(400).json({ message: "Cannot delete event with registrations" })
    }

    // Delete venue
    await Venue.deleteOne({ event: req.params.id })

    // Delete event
    await event.remove()

    res.json({ message: "Event removed" })
  } catch (error) {
    console.error(error)
    res.status(500).json({ message: "Server error" })
  }
}

// Get user events
export const getUserEvents = async (req, res) => {
  try {
    const events = await Event.find({ user: req.user._id }).sort({ date: 1 })
    res.json(events)
  } catch (error) {
    console.error(error)
    res.status(500).json({ message: "Server error" })
  }
}
