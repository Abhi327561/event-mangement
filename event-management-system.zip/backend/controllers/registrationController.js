import Registration from "../models/Registration.js"
import Event from "../models/Event.js"
import Transaction from "../models/Transaction.js"
import { v4 as uuidv4 } from "uuid"

// Register for an event
export const registerForEvent = async (req, res) => {
  try {
    const { eventId, name } = req.body

    // Check if event exists
    const event = await Event.findById(eventId)

    if (!event) {
      return res.status(404).json({ message: "Event not found" })
    }

    // Check if user is already registered
    const existingRegistration = await Registration.findOne({
      eventId,
      user: req.user._id,
    })

    if (existingRegistration) {
      return res.status(400).json({ message: "Already registered for this event" })
    }

    // Create registration
    const registration = await Registration.create({
      name: name || req.user.username,
      eventId,
      user: req.user._id,
      regId: uuidv4(),
    })

    // Create transaction
    const transaction = await Transaction.create({
      amount: event.entryFee,
      status: "pending",
      transactionId: uuidv4(),
      registration: registration._id,
    })

    res.status(201).json({
      registration,
      transaction,
    })
  } catch (error) {
    console.error(error)
    res.status(500).json({ message: "Server error" })
  }
}

// Get user registrations
export const getUserRegistrations = async (req, res) => {
  try {
    const registrations = await Registration.find({ user: req.user._id }).populate("eventId").sort({ regDate: -1 })

    res.json(registrations)
  } catch (error) {
    console.error(error)
    res.status(500).json({ message: "Server error" })
  }
}

// Get event registrations (for event organizers)
export const getEventRegistrations = async (req, res) => {
  try {
    const event = await Event.findById(req.params.eventId)

    if (!event) {
      return res.status(404).json({ message: "Event not found" })
    }

    // Check if user is the event creator
    if (event.user.toString() !== req.user._id.toString()) {
      return res.status(401).json({ message: "Not authorized" })
    }

    const registrations = await Registration.find({ eventId: req.params.eventId })
      .populate("user", "username email phoneNo")
      .sort({ regDate: -1 })

    res.json(registrations)
  } catch (error) {
    console.error(error)
    res.status(500).json({ message: "Server error" })
  }
}

// Cancel registration
export const cancelRegistration = async (req, res) => {
  try {
    const registration = await Registration.findById(req.params.id)

    if (!registration) {
      return res.status(404).json({ message: "Registration not found" })
    }

    // Check if user owns this registration
    if (registration.user.toString() !== req.user._id.toString()) {
      return res.status(401).json({ message: "Not authorized" })
    }

    // Delete associated transaction
    await Transaction.deleteMany({ registration: registration._id })

    // Delete registration
    await registration.remove()

    res.json({ message: "Registration cancelled" })
  } catch (error) {
    console.error(error)
    res.status(500).json({ message: "Server error" })
  }
}
