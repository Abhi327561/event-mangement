import Transaction from "../models/Transaction.js"
import Registration from "../models/Registration.js"

// Get user transactions
export const getUserTransactions = async (req, res) => {
  try {
    // Find user registrations
    const registrations = await Registration.find({ user: req.user._id })
    const registrationIds = registrations.map((reg) => reg._id)

    // Find transactions for those registrations
    const transactions = await Transaction.find({
      registration: { $in: registrationIds },
    }).populate({
      path: "registration",
      populate: { path: "eventId" },
    })

    res.json(transactions)
  } catch (error) {
    console.error(error)
    res.status(500).json({ message: "Server error" })
  }
}

// Get transaction by ID
export const getTransactionById = async (req, res) => {
  try {
    const transaction = await Transaction.findById(req.params.id).populate({
      path: "registration",
      populate: { path: "eventId" },
    })

    if (!transaction) {
      return res.status(404).json({ message: "Transaction not found" })
    }

    // Check if user owns this transaction
    const registration = await Registration.findById(transaction.registration)

    if (registration.user.toString() !== req.user._id.toString()) {
      return res.status(401).json({ message: "Not authorized" })
    }

    res.json(transaction)
  } catch (error) {
    console.error(error)
    res.status(500).json({ message: "Server error" })
  }
}

// Update transaction status
export const updateTransactionStatus = async (req, res) => {
  try {
    const { status } = req.body

    if (!["pending", "completed", "failed"].includes(status)) {
      return res.status(400).json({ message: "Invalid status" })
    }

    const transaction = await Transaction.findById(req.params.id)

    if (!transaction) {
      return res.status(404).json({ message: "Transaction not found" })
    }

    // In a real app, you would verify permissions here
    // For now, we'll just update it

    transaction.status = status
    await transaction.save()

    res.json(transaction)
  } catch (error) {
    console.error(error)
    res.status(500).json({ message: "Server error" })
  }
}
