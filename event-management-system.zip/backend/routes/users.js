import express from "express"
import bcrypt from "bcryptjs"
import User from "../models/User.js"
import Event from "../models/Event.js"
import Registration from "../models/Registration.js"
import Transaction from "../models/Transaction.js"
import { auth } from "../middleware/auth.js"

const router = express.Router()

// Get current user
router.get("/me", auth, async (req, res) => {
  try {
    const user = req.user

    // Return user data without password
    const userResponse = {
      _id: user._id,
      username: user.username,
      email: user.email,
      phoneNo: user.phoneNo,
      gender: user.gender,
      age: user.age,
    }

    res.json(userResponse)
  } catch (error) {
    console.error("Get user error:", error)
    res.status(500).json({ message: "Server error" })
  }
})

// Update user profile
router.put("/me", auth, async (req, res) => {
  try {
    const { username, email, phoneNo, gender, age, currentPassword, newPassword } = req.body
    const user = req.user

    // Check if email is already taken by another user
    if (email !== user.email) {
      const existingUser = await User.findOne({ email })
      if (existingUser) {
        return res.status(400).json({ message: "Email already in use" })
      }
    }

    // Check if username is already taken by another user
    if (username !== user.username) {
      const existingUser = await User.findOne({ username })
      if (existingUser) {
        return res.status(400).json({ message: "Username already in use" })
      }
    }

    // Update basic info
    user.username = username || user.username
    user.email = email || user.email
    user.phoneNo = phoneNo || user.phoneNo
    user.gender = gender || user.gender
    user.age = age || user.age

    // Update password if provided
    if (currentPassword && newPassword) {
      const isMatch = await user.comparePassword(currentPassword)
      if (!isMatch) {
        return res.status(400).json({ message: "Current password is incorrect" })
      }

      // Hash new password
      const salt = await bcrypt.genSalt(10)
      user.password = await bcrypt.hash(newPassword, salt)
    }

    await user.save()

    // Return updated user data without password
    const userResponse = {
      _id: user._id,
      username: user.username,
      email: user.email,
      phoneNo: user.phoneNo,
      gender: user.gender,
      age: user.age,
    }

    res.json(userResponse)
  } catch (error) {
    console.error("Update user error:", error)
    res.status(500).json({ message: "Server error" })
  }
})

// Get dashboard stats
router.get("/dashboard/stats", auth, async (req, res) => {
  try {
    const userId = req.user._id

    // Get counts
    const [myEvents, myRegistrations, transactions] = await Promise.all([
      Event.countDocuments({ user: userId }),
      Registration.countDocuments({ userId }),
      Transaction.find({
        registrationId: { $in: await Registration.find({ userId }).distinct("_id") },
      }),
    ])

    // Get upcoming events (events after today)
    const upcomingEvents = await Event.countDocuments({
      date: { $gte: new Date() },
    })

    res.json({
      myEvents,
      myRegistrations,
      upcomingEvents,
      totalTransactions: transactions.length,
    })
  } catch (error) {
    console.error("Dashboard stats error:", error)
    res.status(500).json({ message: "Server error" })
  }
})

export default router
