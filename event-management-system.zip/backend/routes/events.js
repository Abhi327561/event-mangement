import express from "express"
import Event from "../models/Event.js"
import Registration from "../models/Registration.js"
import { auth } from "../middleware/auth.js"

const router = express.Router()

// Get all events
router.get("/", async (req, res) => {
  try {
    const events = await Event.find().sort({ date: 1 })
    res.json(events)
  } catch (error) {
    console.error("Get events error:", error)
    res.status(500).json({ message: "Server error" })
  }
})

// Get recent events
router.get("/recent", async (req, res) => {
  try {
    const events = await Event.find().sort({ createdAt: -1 }).limit(6)
    res.json(events)
  } catch (error) {
    console.error("Get recent events error:", error)
    res.status(500).json({ message: "Server error" })
  }
})

// Get events created by the current user
router.get("/my-events", auth, async (req, res) => {
  try {
    const events = await Event.find({ user: req.user._id }).sort({ date: 1 })
    res.json(events)
  } catch (error) {
    console.error("Get my events error:", error)
    res.status(500).json({ message: "Server error" })
  }
})

// Get a single event by ID
router.get("/:id", async (req, res) => {
  try {
    const event = await Event.findById(req.params.id)

    if (!event) {
      return res.status(404).json({ message: "Event not found" })
    }

    res.json(event)
  } catch (error) {
    console.error("Get event error:", error)
    res.status(500).json({ message: "Server error" })
  }
})

// Create a new event
router.post("/", auth, async (req, res) => {
  try {
    const { ename, date, entryFee, phoneNo, organizer, venue } = req.body

    const event = new Event({
      ename,
      date,
      entryFee,
      phoneNo,
      organizer,
      venue,
      user: req.user._id,
    })

    await event.save()
    res.status(201).json(event)
  } catch (error) {
    console.error("Create event error:", error)
    res.status(500).json({ message: "Server error" })
  }
})

// Update an event
router.put("/:id", auth, async (req, res) => {
  try {
    const { ename, date, entryFee, phoneNo, organizer, venue } = req.body

    // Check if event exists and belongs to the user
    const event = await Event.findOne({
      _id: req.params.id,
      user: req.user._id,
    })

    if (!event) {
      return res.status(404).json({ message: "Event not found or not authorized" })
    }

    // Update event fields
    event.ename = ename || event.ename
    event.date = date || event.date
    event.entryFee = entryFee || event.entryFee
    event.phoneNo = phoneNo || event.phoneNo
    event.organizer = organizer || event.organizer

    if (venue) {
      event.venue = {
        location: venue.location || event.venue.location,
        capacity: venue.capacity || event.venue.capacity,
        fee: venue.fee || event.venue.fee,
      }
    }

    await event.save()
    res.json(event)
  } catch (error) {
    console.error("Update event error:", error)
    res.status(500).json({ message: "Server error" })
  }
})

// Delete an event
router.delete("/:id", auth, async (req, res) => {
  try {
    // Check if event exists and belongs to the user
    const event = await Event.findOne({
      _id: req.params.id,
      user: req.user._id,
    })

    if (!event) {
      return res.status(404).json({ message: "Event not found or not authorized" })
    }

    // Check if there are registrations for this event
    const registrations = await Registration.find({ eventId: req.params.id })

    if (registrations.length > 0) {
      return res.status(400).json({
        message: "Cannot delete event with active registrations",
      })
    }

    await event.remove()
    res.json({ message: "Event deleted successfully" })
  } catch (error) {
    console.error("Delete event error:", error)
    res.status(500).json({ message: "Server error" })
  }
})

export default router
