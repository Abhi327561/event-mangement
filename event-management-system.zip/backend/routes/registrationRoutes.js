import express from "express"
import {
  registerForEvent,
  getUserRegistrations,
  getEventRegistrations,
  cancelRegistration,
} from "../controllers/registrationController.js"
import { protect } from "../middleware/authMiddleware.js"

const router = express.Router()

router.route("/").post(protect, registerForEvent).get(protect, getUserRegistrations)

router.route("/event/:eventId").get(protect, getEventRegistrations)

router.route("/:id").delete(protect, cancelRegistration)

export default router
