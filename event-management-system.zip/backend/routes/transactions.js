import express from "express"
import Transaction from "../models/Transaction.js"
import Registration from "../models/Registration.js"
import { auth } from "../middleware/auth.js"

const router = express.Router()

// Get all transactions for the current user
router.get("/my-transactions", auth, async (req, res) => {
  try {
    // Find all registrations for the user
    const registrations = await Registration.find({ userId: req.user._id })
    const registrationIds = registrations.map((reg) => reg._id)

    // Find transactions for those registrations
    const transactions = await Transaction.find({
      registrationId: { $in: registrationIds },
    }).populate({
      path: "registrationId",
      populate: { path: "eventId" },
    })

    res.json(transactions)
  } catch (error) {
    console.error("Get transactions error:", error)
    res.status(500).json({ message: "Server error" })
  }
})

// Get a specific transaction
router.get("/:id", auth, async (req, res) => {
  try {
    const transaction = await Transaction.findById(req.params.id).populate({
      path: "registrationId",
      populate: { path: "eventId" },
    })

    if (!transaction) {
      return res.status(404).json({ message: "Transaction not found" })
    }

    // Check if the transaction belongs to the user
    const registration = await Registration.findById(transaction.registrationId)

    if (registration.userId.toString() !== req.user._id.toString()) {
      return res.status(403).json({ message: "Not authorized to view this transaction" })
    }

    res.json(transaction)
  } catch (error) {
    console.error("Get transaction error:", error)
    res.status(500).json({ message: "Server error" })
  }
})

// Update transaction status (in a real app, this would be handled by payment webhooks)
router.put("/:id/status", auth, async (req, res) => {
  try {
    const { status } = req.body

    if (!["pending", "completed", "failed"].includes(status)) {
      return res.status(400).json({ message: "Invalid status" })
    }

    const transaction = await Transaction.findById(req.params.id)

    if (!transaction) {
      return res.status(404).json({ message: "Transaction not found" })
    }

    // In a real app, you would verify that the user has permission to update this
    // For now, we'll just update it
    transaction.status = status
    await transaction.save()

    res.json(transaction)
  } catch (error) {
    console.error("Update transaction error:", error)
    res.status(500).json({ message: "Server error" })
  }
})

export default router
