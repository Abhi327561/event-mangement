import express from "express"
import Registration from "../models/Registration.js"
import Event from "../models/Event.js"
import Transaction from "../models/Transaction.js"
import { auth } from "../middleware/auth.js"

const router = express.Router()

// Get all registrations for the current user
router.get("/my-registrations", auth, async (req, res) => {
  try {
    const registrations = await Registration.find({ userId: req.user._id })
      .populate("eventId")
      .populate("transaction")
      .sort({ regDate: -1 })

    // Format the response to include event details
    const formattedRegistrations = registrations.map((reg) => ({
      _id: reg._id,
      name: reg.name,
      regDate: reg.regDate,
      event: reg.eventId,
      transaction: reg.transaction,
    }))

    res.json(formattedRegistrations)
  } catch (error) {
    console.error("Get registrations error:", error)
    res.status(500).json({ message: "Server error" })
  }
})

// Get registrations for a specific event (for event organizers)
router.get("/event/:eventId", auth, async (req, res) => {
  try {
    const { eventId } = req.params

    // Check if the user is the event organizer
    const event = await Event.findOne({
      _id: eventId,
      user: req.user._id,
    })

    if (!event) {
      return res.status(403).json({ message: "Not authorized to view these registrations" })
    }

    const registrations = await Registration.find({ eventId })
      .populate("userId", "username email phoneNo")
      .populate("transaction")
      .sort({ regDate: -1 })

    res.json(registrations)
  } catch (error) {
    console.error("Get event registrations error:", error)
    res.status(500).json({ message: "Server error" })
  }
})

// Register for an event
router.post("/", auth, async (req, res) => {
  try {
    const { eventId, name } = req.body

    // Check if event exists
    const event = await Event.findById(eventId)
    if (!event) {
      return res.status(404).json({ message: "Event not found" })
    }

    // Check if user is already registered for this event
    const existingRegistration = await Registration.findOne({
      eventId,
      userId: req.user._id,
    })

    if (existingRegistration) {
      return res.status(400).json({ message: "Already registered for this event" })
    }

    // Create registration
    const registration = new Registration({
      eventId,
      userId: req.user._id,
      name: name || req.user.username,
      regDate: new Date(),
    })

    await registration.save()

    // Create transaction record
    const transaction = new Transaction({
      registrationId: registration._id,
      amount: event.entryFee,
      status: "pending", // In a real app, this would be handled by payment processing
    })

    await transaction.save()

    // Update registration with transaction reference
    registration.transaction = transaction._id
    await registration.save()

    res.status(201).json({
      registration,
      transaction,
    })
  } catch (error) {
    console.error("Registration error:", error)
    res.status(500).json({ message: "Server error" })
  }
})

// Cancel registration
router.delete("/:id", auth, async (req, res) => {
  try {
    // Find registration and check if it belongs to the user
    const registration = await Registration.findOne({
      _id: req.params.id,
      userId: req.user._id,
    })

    if (!registration) {
      return res.status(404).json({ message: "Registration not found or not authorized" })
    }

    // Delete associated transaction
    if (registration.transaction) {
      await Transaction.findByIdAndDelete(registration.transaction)
    }

    // Delete registration
    await registration.remove()

    res.json({ message: "Registration cancelled successfully" })
  } catch (error) {
    console.error("Cancel registration error:", error)
    res.status(500).json({ message: "Server error" })
  }
})

export default router
