import express from "express"
import {
  getUserTransactions,
  getTransactionById,
  updateTransactionStatus,
} from "../controllers/transactionController.js"
import { protect } from "../middleware/authMiddleware.js"

const router = express.Router()

router.route("/").get(protect, getUserTransactions)

router.route("/:id").get(protect, getTransactionById)

router.route("/:id/status").put(protect, updateTransactionStatus)

export default router
